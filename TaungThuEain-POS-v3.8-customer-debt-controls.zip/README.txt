TaungThuEain POS v3.8

1) Replace the hosted index.html with this package's index.html and deploy/push to GitHub Pages.
2) Copy firestore.rules into Firebase Console > Firestore Database > Rules, then Publish.
3) In the Admin account, open Settings > Staff permissions, select one staff account, toggle permissions, and Save.
4) Staff must sign out and sign in again after permissions are changed.

New per-staff permissions:
- allowAddCustomer: add new customers
- allowManageRepayments: edit/delete repayment records
- allowManageDebts: edit/delete customer debt records

Customer profile edit/delete remains Admin-only. Debt records recovered from sales history are labeled as sales-derived and are not directly editable; use the original sale record controls for those.
