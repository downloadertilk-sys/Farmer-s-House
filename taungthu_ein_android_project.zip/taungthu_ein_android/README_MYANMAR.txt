တောင်သူ့အိမ် POS - Android Studio Project

သတိပြုရန်
- ဒီ ZIP သည် APK ဖိုင်မဟုတ်ပါ။ Android Studio ဖြင့် APK တည်ဆောက်ရန် project source ဖြစ်သည်။
- HTML သည် Firebase Web SDK ကို အင်တာနက်မှ load လုပ်သည်။ အသုံးပြုရန် အင်တာနက်လိုသည်။
- Firebase Authentication, Firestore database နှင့် Security Rules ကို အရင်ပြင်ဆင်ပါ။
- Firebase Web config သည် app ထဲတွင်ပါဝင်နေသည်။ Service-account private key များကို မထည့်ပါနှင့်။

APK ထုတ်နည်း (ကွန်ပျူတာလိုအပ်သည်)
1. Android Studio ကို install လုပ်ပါ။
2. Android Studio > Open ကိုနှိပ်ပြီး ဒီ project folder (TaungThuEinPOS) ကိုရွေးပါ။
3. Gradle Sync ပြီးစီးသည်အထိ စောင့်ပါ။ SDK 35 နှင့် လိုအပ်သော build tools ကို install လုပ်ပါ။
4. Build > Build Bundle(s) / APK(s) > Build APK(s) ကိုနှိပ်ပါ။
5. APK သည် app/build/outputs/apk/debug/app-debug.apk တွင် ရလာမည်။

မှတ်ချက်
WebView ထဲက file:// origin ကြောင့် Firebase Auth သို့မဟုတ် Firestore ချိတ်ဆက်မှု အမှားပြပါက HTTPS hosting (ဥပမာ Firebase Hosting) ပေါ်တင်ပြီး app ကို hosted URL ဖြင့် load လုပ်ရန် လိုနိုင်သည်။ မဖြန့်ချိမီ ဖုန်းတွင် login, sales, stock update, export တို့ကို စမ်းသပ်ပါ။
