TaungThuEain POS Android launcher icon assets v4.
Legacy density-specific PNG launcher icons only.
Adaptive icon XML/foreground resources are intentionally excluded to avoid
Android selecting the conflicting Capacitor adaptive icon resources.
