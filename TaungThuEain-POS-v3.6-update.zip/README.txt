တောင်သူ့အိမ် POS v3.6 Update

ပါဝင်သောဖိုင်များ
- index.html: POS source အသစ် (Logo ထည့်ပြီး၊ အရောင်းပစ္စည်းတူများကို ပေါင်းပြထားသည်)
- taungthu-eain-logo.png: မူရင်း Logo (transparent)
- taungthu-eain-app-icon-192.png / 512.png: App/PWA icon
- manifest.webmanifest: PWA app name/icon settings

ပြင်ဆင်ထားသောအချက်များ
1. ပစ္စည်းအမည်နှင့် အမျိုးအစားတူသော stock record များကို POS ပစ္စည်းရွေးချယ်ရာတွင် တစ်ကတ်တည်းပြသည်။
2. အရောင်းဘောင်ချာထဲတွင်လည်း တစ်ကြောင်းတည်းပြပြီး အရေအတွက်ပေါင်းသည်။
3. ရောင်းချချိန်တွင် မူရင်း stock record တစ်ခုချင်းစီမှ အရေအတွက်ကို မှန်ကန်စွာလျှော့သည်။
4. Login စာမျက်နှာ၊ အပေါ် Header နှင့် Web/PWA icon တွင် Logo ထည့်ထားသည်။

မှတ်ချက်
Android APK ၏ ဖုန်း Home Screen Launcher Icon သည် Android project ၏ res/mipmap resources မှ သတ်မှတ်ထားပါက,
ဤ ZIP ထဲရှိ taungthu-eain-app-icon-512.png ကို Android project ထဲတွင် ထည့်သွင်းပြီး APK ပြန် build လုပ်ရန် လိုသည်။
HTML ဖိုင်တစ်ခုတည်းဖြင့် ရှိပြီးသား APK ၏ native launcher icon ကို တိုက်ရိုက်မပြောင်းနိုင်ပါ။
