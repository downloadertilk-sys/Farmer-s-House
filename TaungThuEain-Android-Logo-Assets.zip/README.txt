တောင်သူ့အိမ် Android App Logo Assets

အသုံးပြုရန်:
1. ZIP ထဲရှိ res ဖိုလ်ဒါကို Android project ၏ app/src/main/res/ ထဲသို့ ထည့်ပါ။
2. AndroidManifest.xml တွင် application ၏ icon ကို @mipmap/ic_launcher သတ်မှတ်ပါ။
3. Adaptive icon ကို Android 8.0 နှင့်အထက်တွင် အသုံးပြုနိုင်သည်။
4. APK အသစ် build လုပ်ပြီး ဖုန်းတွင် install/update လုပ်ပါ။

မှတ်ချက်: ဤဖိုင်သည် icon resources သာဖြစ်ပြီး APK ကိုယ်တိုင် မဟုတ်ပါ။
