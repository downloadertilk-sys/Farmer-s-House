TaungThuEain POS Android launcher icon assets v3.
Includes both ic_launcher and ic_launcher_round resources at all standard densities,
plus adaptive icon XML/foreground resources. The workflow must also set the Android
manifest android:icon and android:roundIcon to @mipmap/ic_launcher and
@mipmap/ic_launcher_round respectively.
